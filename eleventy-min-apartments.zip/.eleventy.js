module.exports = function() {
  return {
    dir: { input: "src", output: "_site", data: "_data" },
    htmlTemplateEngine: "njk"
  };
};
